﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Producer.Controllers
{
    public class CallBPIService : IHostedService, IDisposable
    {
        private readonly ILogger<CallBPIService> logger;
        private Timer timer;
        private int number;

        public CallBPIService(ILogger<CallBPIService> logger)
        {
            this.logger = logger;
        }

        public void Dispose()
        {
            timer?.Dispose();
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            timer = new Timer(o => {
                Interlocked.Increment(ref number);
                logger.LogInformation($"Starting to Call BPI Service");
                CallService();
            },
            null,
            TimeSpan.Zero,
            TimeSpan.FromMinutes(15));

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
        private void CallService()
        {

            var factory = new ConnectionFactory()
            {
                HostName = Environment.GetEnvironmentVariable("RABBITMQ_HOST"),
                Port = Convert.ToInt32(Environment.GetEnvironmentVariable("RABBITMQ_PORT"))
            };


            using (var client = new HttpClient())
            {
                //var content =  client.GetStringAsync("https://api.coindesk.com/v1/bpi/currentprice.json").;
                // client.BaseAddress = new Uri("https://api.coindesk.com/v1/bpi/currentprice.json");
                client.DefaultRequestHeaders.Accept.Clear();
                //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                // HttpContent c = new StringContent(strPayload, Encoding.UTF8, "application/json");
                var response = client.GetStringAsync("https://api.coindesk.com/v1/bpi/currentprice.json").Result;
                Console.WriteLine(factory.HostName + ":" + factory.Port);
                using (var connection = factory.CreateConnection())
                using (var channel = connection.CreateModel())
                {
                    channel.QueueDeclare(queue: "Bpi",
                                         durable: false,
                                         exclusive: false,
                                         autoDelete: false,
                                         arguments: null);
                    var body = Encoding.UTF8.GetBytes(response.ToString());

                    channel.BasicPublish(exchange: "",
                                         routingKey: "Bpi",
                                         basicProperties: null,
                                         body: body);
                }

            }

        }
    }
}
